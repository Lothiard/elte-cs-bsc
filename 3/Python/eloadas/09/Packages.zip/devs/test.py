def mapper(fun, lst: list):
    return [fun(x) for x in lst]

def multimapper(fun, lst, *args):
    return [fun(x, *args) for x in lst]

def lister(lst: list):
    return [x*2 for x in lst]

PI = 3.14