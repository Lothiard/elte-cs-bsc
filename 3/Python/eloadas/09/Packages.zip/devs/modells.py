class User:
    __defage__ = 10
    def __init__(self, name):
        self.name = name
    
    def __str__(self):
        return self.name

def function():
    return 'function'    