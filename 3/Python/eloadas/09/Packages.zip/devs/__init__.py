from .test import mapper, lister, multimapper, PI
from .modells import User
from .inner.innermodul import BIGPI

PIPI = PI * 3.14

print("Package has been loaded")