from devs import lister, mapper, multimapper, User, PI, PIPI, BIGPI

class user(User):
    def __init__(self, name):
        super().__init__(name)
        
    def setAge(self, age):
        self.age = age
        
    def getAge(self):
        return self.age

def main():
    
    usr =user("Rol")
    print(usr)
    print(usr.getAge)
    usr.setAge(20)
    print(usr.__defage__)
    print(user.__defage__)
    print(User.__defage__)
    
    print(lister([1, 2, 3, 4]))
    print(mapper(lambda x: x * 4 , [1, 2, 3, usr.getAge(), usr.__defage__]))
    print(multimapper(lambda x, y, z: x * y + z , [1, 2, 3, 4], 2, 5))

    print(PI)
    print(PIPI)
    print(BIGPI)

if __name__ == "__main__":
    main()
