import matplotlib.pyplot as plt

honapok = ["Január", "Február", "Március", "Április", "Május", "Június"]
bevetelek = [200, 250, 300, 280, 320, 310]

plt.plot(honapok, bevetelek, marker='s', color='g')
plt.title('Cég havi bevételei', fontsize=16, fontweight='bold', color='navy')
plt.xlabel('Hónapok', fontsize=12, color='darkgreen')
plt.ylabel('Bevétel (ezer Ft)', fontsize=12, color='darkgreen')
plt.xticks(rotation=45)            
# x tengely értékek elforgatása
plt.grid(color='gray', linestyle='--', linewidth=0.5)
plt.show()

"""
color='gray':

A rácsvonalak színét szürkére állítja.
Ez egy diszkrét színválasztás, amely nem vonja el 
a figyelmet a diagram fő elemeiről.
linestyle='-':

A rácsvonalak stílusát határozza meg.
A '-' érték folytonos vonalat jelent. 

Más opciók például:

'--': Szaggatott vonal.
':': Pontozott vonal.
'-.': Pontozott-szaggatott vonal.

linewidth=0.5:

A rácsvonalak vastagságát állítja be.
A 0.5 érték egy vékony vonalat eredményez, amely 
kevésbé dominál a diagramon.
"""