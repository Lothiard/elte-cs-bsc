import matplotlib.pyplot as plt


honapok = ["Január", "Február", "Március", "Április", "Május", "Június"]
bevetelek = [200, 250, 300, 280, 320, 310]
kiadasok = [800, 900, 950, 870, 1000, 1200]

plt.figure(figsize=(10, 5))

# Első subplot
plt.subplot(2, 2, 1)  

# 1 sor, 2 oszlop, 1. subplot
plt.plot(honapok, bevetelek, color='blue', marker='o')
plt.title('Havi bevételek')
plt.xlabel('Hónapok')
plt.ylabel('Bevétel (ezer Ft)')

# Második subplot
plt.subplot(2, 2, 2)  
# 1 sor, 2 oszlop, 2. subplot

plt.plot(honapok, kiadasok, color='red', marker='*')
"""
A marker paraméter a pontok megjelenését szabályozza a diagramon.
A 'd' érték egy rombusz alakú jelölőt jelent.

'o': Kör
's': Négyzet
'^': Háromszög (felfelé mutató)
'v': Háromszög (lefelé mutató)
'x': Kereszt
'+': Pluszjel
'*': Csillag
'd': Rombusz
'D': Nagy rombusz
"""
plt.title('Havi kiadások')
plt.xlabel('Hónapok')
plt.ylabel('Kiadások (ezer Ft)')
plt.tight_layout()

# 3. subplot
plt.subplot(2, 2, 3)  

# 1 sor, 2 oszlop, 1. subplot
plt.plot(honapok, bevetelek, color='blue', marker='o')
plt.title('Havi bevételek')
plt.xlabel('Hónapok')
plt.ylabel('Bevétel (ezer Ft)')

# Igazítás a helyes megjelenítéshez
plt.show()
