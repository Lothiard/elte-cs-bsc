# Vonal-diagram készítése közvetlenül Pandas segítségével
import pandas as pd
import matplotlib.pyplot as plt


adatok = pd.read_csv('eladasok2.csv')
adatok.plot(x='Nap', y='Eladás', kind='line', 
            marker='x', color='green', title='Napi eladások')

"""
A Pandas beépített plot metódusának segítségével
a Matplotlib-et használjuk a megjelenítéshez.

"""
plt.xlabel('Napok')
plt.ylabel('Eladások (db)')
plt.grid(True)
plt.show()
# A beolvasott adatok megtekintése
print(adatok.head())
