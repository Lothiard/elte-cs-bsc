import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt

# Adatok generálása DataFrame-ben
adatok = pd.DataFrame({    
    'Nap': ['Hétfő', 'Kedd', 'Szerda', 'Csütörtök', 'Péntek', 'Szombat', 'Vasárnap'],
    'Eladás': [150, 200, 170, 240, 300, 400, 320],
    'Látogatók': [200, 250, 230, 300, 350, 500, 450]
    })

adatok2 = pd.read_csv('eladasok2.csv')


sns.histplot(adatok['Eladás'], kde=True, color='teal')
plt.title('Eladások eloszlása')
plt.xlabel('Eladások száma')
plt.ylabel('Gyakoriság')
plt.show()

