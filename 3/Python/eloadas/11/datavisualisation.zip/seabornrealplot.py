import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt

# Adatok generálása DataFrame-ben
adatok = pd.DataFrame({    
    'Nap': ['Hétfő', 'Kedd', 'Szerda', 'Csütörtök', 'Péntek', 'Szombat', 'Vasárnap'],
    'Eladás': [150, 200, 170, 240, 300, 400, 320],
    'Látogatók': [200, 250, 230, 300, 350, 500, 450]
    })

adatok2 = pd.read_csv('eladasok2.csv')
print(adatok2.head())
sns.relplot(x='Látogatók', y='Eladás', data=adatok2,
                      kind='scatter')
plt.title('Látogatók és eladások közötti kapcsolat')
plt.show()


