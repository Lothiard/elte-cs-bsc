# Scatter plot készítése a látogatók száma és eladások közötti kapcsolat
#  ábrázolására
import pandas as pd
import matplotlib.pyplot as plt

adatok = pd.read_csv('eladasok2.csv')
napok = adatok['Nap']

adatok.plot(kind='scatter', x='Látogatók', y='Eladás', color='red',
            title='Látogatók és eladások közötti kapcsolat')
print(adatok.head())
plt.xlabel('Látogatók száma')
plt.ylabel('Eladások (db)')
plt.show()
