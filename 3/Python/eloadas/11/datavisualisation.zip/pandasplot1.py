import pandas as pd
import matplotlib.pylab as plt

adatok = pd.read_csv('eladasok.csv')
napok = adatok['Nap']
eladások = adatok['Eladás']


plt.plot(napok, eladások, marker='x')
plt.title('Napi eladások')
plt.xlabel('Napok')
plt.ylabel('Eladások (db)')
plt.style.use('fivethirtyeight')
plt.show()
print(adatok.head())
