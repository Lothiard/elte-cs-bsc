import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt

# Adatok generálása DataFrame-ben
adatok = pd.DataFrame({    
    'Nap': ['Hétfő', 'Kedd', 'Szerda', 'Csütörtök', 'Péntek', 'Szombat', 'Vasárnap'],
    'Eladás': [150, 200, 170, 240, 300, 400, 320],
    'Látogatók': [200, 250, 230, 300, 350, 500, 450]
    })

adatok2 = pd.read_csv('eladasok2.csv')



sns.boxplot(y=adatok['Eladás'], color='lightgreen', width=0.3)
plt.title('Heti eladások dobozábrája')
plt.ylabel('Eladások száma')
plt.show()
