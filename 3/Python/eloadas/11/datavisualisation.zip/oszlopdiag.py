import pandas as pd
import matplotlib.pyplot as plt

adatok = pd.read_csv('eladasok.csv')
napok = adatok['Nap']
eladások = adatok['Eladás']

adatok.plot(x='Nap', y='Eladás', kind='bar', color='coral', title='Napi eladások oszlopdiagramon')
plt.xlabel('Napok')
plt.ylabel('Eladások (db)')
plt.show()