import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt

adatok = pd.read_csv('eladasok2.csv')
print(adatok.head())
sns.pairplot(adatok)
plt.suptitle('Páros diagram az eladások és látogatók',
              y=1.0)
plt.show()
