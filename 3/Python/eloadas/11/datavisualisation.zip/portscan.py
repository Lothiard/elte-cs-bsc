import socket # (TCP/UDP socketek, DNS feloldás stb.)
import sys

RemoteServer = input("Host: ")
try:
    RemoteServerIP = socket.gethostbyname(RemoteServer)
    # DNS‑feloldás hostnévről IPv4 címre
except socket.gaierror:
    print("Nem feloldható a cím")
    sys.exit(1)

# melyik hostot és IP‑t fogja vizsgálni a szkrip
print(f"Scanning host {RemoteServer} ({RemoteServerIP})")
try:
    for port in range(1, 11025):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # IPV4, TCP socket (AF_INET, SOCK_STREAM).
        sock.settimeout(0.5) # Timeout
        result = sock.connect_ex((RemoteServerIP, port))
        # TCP kapcsolatot nyit, kivétel helyett hibakódot dob
        if result == 0:
            print(f"Port {port}: Open")
        sock.close()
except KeyboardInterrupt:
    print("Interrupted")
    sys.exit(0)
