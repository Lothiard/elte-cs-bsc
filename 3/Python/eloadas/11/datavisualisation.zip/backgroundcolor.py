import matplotlib.pyplot as plt
import pandas as pd

data = {'X': [1, 2, 3, 4, 5], 'Y': [2, 3, 5, 8, 13]}
df = pd.DataFrame(data)


fig = plt.figure(facecolor='lightgreen')  

ax = plt.gca()  # Az aktuális tengelyek lekérése

ax.set_facecolor('lightblue')
                 
# Adatok ábrázolása 
plt.plot(df['X'], df['Y'], 'ro') 

"""
df['X']: Az x-tengely értékei a DataFrame X oszlopából
df['Y']: Az y-tengely értékei a DataFrame Y oszlopából

r: A pontok színe piros (red).
o: A pontok alakja kör (circle).
"""

# Diagram megjelenítése

plt.show()