import matplotlib.pyplot as plt
import random 

latogatok = [random.randint(50, 200) for _ in range(14)]
print(latogatok)  # Ellenőrzéshez kiírjuk a generált listát

eloadasok = [random.randint(50, 200) for _ in range(14)]
print(eloadasok)  # Ellenőrzéshez kiírjuk a generált listát

latogatok = [120, 150, 180, 200, 170, 160, 140, 180, 190, 210, 190, 200]
eloadasok = [150, 180, 220, 240, 200, 230, 170, 190, 210, 250, 230, 220]

#plt.scatter(latogatok, eloadasok, color='red')
"""
Két változó közötti kapcsolat vizsgálatára, például 
korrelációk ábrázolására.
"""

#plt.plot(latogatok, eloadasok, color='orange', marker='o'   , linestyle='None')
plt.plot(latogatok, eloadasok, color='orange', marker='o')
"""
Folytonos adatok ábrázolására, például időbeli változások vagy 
trendek megjelenítésére.
"""

plt.title('Látogatók száma és előadások közötti kapcsolat.')
plt.xlabel("Látogatók száma")
plt.ylabel("Előadások száma")
plt.grid(True)
plt.show()