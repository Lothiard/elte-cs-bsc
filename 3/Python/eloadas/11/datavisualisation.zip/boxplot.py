
import matplotlib.pyplot as plt

"""
Medián: A doboz belsejében egy vonal jelzi az adatok mediánját.

Kvartilisek: A doboz alsó és felső széle az első és 
harmadik kvartilist mutatja.

???
A kvartilisek az adatok eloszlásának három olyan pontját jelentik, 
amelyek az adatokat négy egyenlő részre osztják. 

Első kvartilis (Q1):
    Az adatok alsó 25%-ának határértéke.
    Az az érték, amely alatt az adatok 25%-a található.
    A Medián   a Q2:

Az adatok középső értéke (50%-os határ).
Az az érték, amely alatt és fölött az adatok 50%-a található.
Harmadik kvartilis (Q3):

Az adatok felső 25%-ának határértéke.
Az az érték, amely alatt az adatok 75%-a található.

Hogyan kapcsolódik a boxplothoz?

A doboz alsó széle az első kvartilist (Q1) jelöli.
A doboz felső széle a harmadik kvartilist (Q3) jelöli.
A doboz belsejében lévő vonal a mediánt (Q2) mutatja.

Kiugró értékek: Az adatokból kiugró értékeket külön pontok jelzik.
Terjedelem: 

A "bajszok" (whiskers) az adatok minimális és 
maximális értékeit mutatják (kiugrók nélkül).
"""

import matplotlib.pyplot as plt

heti_eladasok = [150, 180, 220, 240, 200, 230, 170, 190, 210, 250, 230, 220, 180, 195, 205]
# Box plot készítése
plt.boxplot(heti_eladasok, patch_artist=True, 
            boxprops=dict(facecolor='lightgreen'))
plt.title('Heti eladások dobozábrája')
plt.ylabel('Eladások száma')
plt.grid(axis='y', linestyle='--', linewidth=0.5)
plt.show()
