import matplotlib.pyplot as plt

# Példa adatok: havi bevételek (ezer forintban)
honapok = ["Január", "Február", "Március", "Április", "Május", "Június"]
bevetelek = [200, 250, 300, 280, 320, 310]

# Vonaldiagram létrehozása
plt.plot(honapok, bevetelek, color='blue', marker='o', linestyle='-')

# Tengelyek és cím hozzáadása
plt.title("Cég havi bevételei")
plt.xlabel("Hónapok")
plt.ylabel("Bevétel (ezer forint)")
plt.grid(True)

# Diagram megjelenítése
plt.show()