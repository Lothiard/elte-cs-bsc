import matplotlib.pyplot as plt
import pandas as pd
# Adatok generálása 
eladasok = [150, 180, 220, 240, 200, 230, 170, 190, 210, 250, 230, 220]

"""
A hisztogram az adatok eloszlását úgy számolja ki, hogy az értékeket
osztályokba (bin-ekbe) csoportosítja, majd megszámolja, 
hogy az egyes osztályokba hány adatpont esik. 
Az osztályok szélességét és számát a bins paraméter 
határozza meg.
"""

# Hisztogram készítése
plt.hist(eladasok, bins=6, color='lightblue', edgecolor='black')
plt.title('Napi eladások eloszlása')
plt.xlabel('Eladások száma')
plt.ylabel('Gyakoriság')
plt.grid(axis='y', linestyle='--', linewidth=0.5)
plt.show()
