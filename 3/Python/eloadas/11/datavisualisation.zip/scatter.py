import matplotlib.pyplot as plt
# Adatok generálása

latogatok = [120, 150, 180, 200, 170, 160, 140, 180, 190, 210, 190, 200]
eladasok = [150, 180, 220, 240, 200, 230, 170, 190, 210, 250, 230, 220]

# Scatter plot készítése
plt.scatter(latogatok, eladasok, color='orange')
plt.title('Látogatók száma és eladások közötti kapcsolat')
plt.xlabel('Látogatók száma')
plt.ylabel('Eladások száma')
plt.grid(True)

plt.show()
