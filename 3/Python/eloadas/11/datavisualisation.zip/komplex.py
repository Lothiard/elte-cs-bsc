import pandas as pd
import matplotlib.pyplot as plt

napok = ['Hétfő', 'Kedd', 'Szerda', 'Csütörtök', 'Péntek', 'Szombat', 'Vasárnap']
homerseklet = [20, 22, 21, 23, 24, 25, 22]  # Celsius fok
csapadek = [5, 10, 0, 0, 2, 1, 8]  # mm

plt.plot(napok, homerseklet, marker='o', color='red', 
         label='Hőmérséklet (C°)')
plt.plot(napok, csapadek, marker='s', color='blue', 
         linestyle='--', label='Csapadék (mm)')

plt.title('Heti időjárás: hőmérséklet és csapadék')
plt.xlabel('Napok')
plt.ylabel('Érték')
plt.legend()
plt.grid(True)
plt.show()
