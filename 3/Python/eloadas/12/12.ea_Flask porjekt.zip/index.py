from flask import Flask, redirect, url_for

app = Flask(__name__)

@app.route('/')
def home():
    return '<h1>Hello Flask</h1>'

@app.route('/users/<name>')
def users(name: str) -> str:
    return f"Hello {name}"

@app.route("/login/<name>")
def login(name):
    return redirect(url_for("users", name=name))

if __name__ == '__main__':
    app.run()