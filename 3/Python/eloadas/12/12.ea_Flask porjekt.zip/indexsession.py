from flask import Flask, request, url_for
from flask import render_template, redirect, session, flash
from datetime import timedelta

app = Flask(__name__)
app.secret_key = 'alma'
app.permanent_session_lifetime = timedelta(minutes=20)

@app.route('/')
def home():
    return render_template("index5.html")

@app.route('/loginpage', methods=["POST", "GET"])
def loginpage():
    if request.method == "POST":
        session.permanent = True
        username = request.form["username"]
        session["user"] = username
        return redirect(url_for("user"))
    else:
        return render_template("login.html") 

@app.route('/user')
def user():
    if "user" in session:
        user = session["user"]
        return f"<h1>{user} from session.</h1>"
    else:
        return f"<h1>nouser in session</h1>"
        #return redirect(url_for("loginpage"))

@app.route('/logout')
def logout():
    session.pop("user", None)
    flash("You have been logged out!", "Message ")
    return f"<h1>Logged out</h1>"
    #return redirect(url_for("loginpage"))

@app.route('/logoutfls')
def logoutfls():
    if 'username' in session:
        user = session["username"]
        session.pop("username", None)
        flash("Logout", "User logged out!")
        return redirect(url_for("loginpage"))
    else:
        flash("No user!")
        return redirect(url_for('home'))

@app.route('/otherpage')
def otherpage():
    return "Logout, no session!"
    #return render_template("template.html")
    

if __name__ == '__main__':
    app.run(debug=True)