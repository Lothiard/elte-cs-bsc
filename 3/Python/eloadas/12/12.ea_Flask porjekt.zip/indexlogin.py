from flask import Flask, request, url_for, render_template, redirect

app = Flask(__name__)

@app.route('/')
def home():
    return render_template("index5.html")

@app.route('/loginpage', methods=["POST", "GET"])
def loginpage():
    if request.method == "POST":
        username = request.form["username"]
        return redirect(url_for("user", usr=username))
    else:
        return render_template("login.html") 

@app.route('/<usr>')
def user(usr):
    return f"<h1>{usr}</h1>"

@app.route('/otherpage')
def otherpage():
    return render_template("template.html")

if __name__ == '__main__':
    app.run()