from flask import Flask, render_template

app = Flask(__name__)

@app.route('/<data>')
def route(data: str):
    return render_template("simple2.html",  bodycontent=data)

@app.route('/users/<user>')
def users(user: str):
    return render_template("simple3.html",
                           bodycontent=user, 
                           message="Loged in")

if __name__ == "__main__":
    app.run(debug=True)