﻿namespace ELTE.DocuStat.Persistence
{
    public interface IFileManager
    {
        string Load();
    }
}
