﻿using System.Windows.Forms;

namespace ELTE.DigiClock
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

    }
}
