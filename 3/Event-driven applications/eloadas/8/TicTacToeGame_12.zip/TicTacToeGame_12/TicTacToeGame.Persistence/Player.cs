﻿
namespace ELTE.TicTacToeGame.Persistence
{
    /// <summary>
    /// Játékos felsorolási típusa.
    /// </summary>
    public enum Player
    {
        NoPlayer,
        PlayerX,
        PlayerO
    }
}
