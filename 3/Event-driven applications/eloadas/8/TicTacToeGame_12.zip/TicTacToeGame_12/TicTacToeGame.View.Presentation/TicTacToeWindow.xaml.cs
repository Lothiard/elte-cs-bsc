﻿using System.Windows;

namespace ELTE.TicTacToeGame.View
{
    public partial class TicTacToeWindow : Window
    {
        public TicTacToeWindow()
        {
            InitializeComponent();
        }
    }
}
