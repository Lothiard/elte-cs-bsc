﻿using System.Windows;
using ELTE.StudentsList.ViewModel;

namespace ELTE.StudentsList.View
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
