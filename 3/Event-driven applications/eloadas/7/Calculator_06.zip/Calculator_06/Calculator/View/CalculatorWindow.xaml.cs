﻿using System.Windows;
using System.Windows.Controls;

namespace ELTE.Calculator.View
{
    public partial class CalculatorWindow : Window
    {
        public CalculatorWindow()
        {
            InitializeComponent();
        }
    }
}
