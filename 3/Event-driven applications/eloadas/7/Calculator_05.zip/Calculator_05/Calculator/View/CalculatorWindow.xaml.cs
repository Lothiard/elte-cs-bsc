﻿using System.Windows;

namespace ELTE.Calculator.View
{
    public partial class CalculatorWindow : Window
    {
        public CalculatorWindow()
        {
            InitializeComponent();
        }
    }
}
