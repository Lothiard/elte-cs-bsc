﻿using System.Windows;

namespace ELTE.SimpleWindowByDesign
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
