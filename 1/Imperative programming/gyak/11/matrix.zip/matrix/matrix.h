#ifndef MATRIX_H
#define MATRIX_H

struct matrix;
typedef struct matrix Matrix;

Matrix *matrix_init(int n, int m);
int    *matrix_at(Matrix*, int i, int j);

Matrix *matrix_mul(Matrix *a, Matrix *b);
#endif