#include "matrix.h"
#include <stdlib.h>
#include <string.h>

struct matrix {
    int n, m;
    int *values;
};

Matrix *matrix_init(int n, int m) {
    if (n < 0 || m < 0) return NULL;

    size_t alloc_size = n * m * sizeof(int);

    int *values = malloc(alloc_size);
    memset(values, 0, alloc_size);

    Matrix *mat = malloc(sizeof(Matrix));

    mat->n = n;
    mat->m = m;
    mat->values = values;

    return mat;
}

int *matrix_at(Matrix *mat, int i, int j) {
    if (i < 0 || i >= mat->n) return NULL;
    if (j < 0 || j >= mat->m) return NULL;

    return &mat->values[i * mat->n + j];
}

Matrix *matrix_mul(Matrix *a, Matrix *b) {
    Matrix *res = matrix_init(a->n, b->m);

    if (res == NULL) return NULL;

    if (a->m != b->n) return NULL;

    for (int i = 0; i < a->n; ++i) {
        for (int j = 0; j < b->m; ++j) {
            int value = 0;

            for (int k = 0; k < a->m; ++k)
                value += *matrix_at(a, i, k) * *matrix_at(b, k, j);

            *matrix_at(res, i, j) = value;
        }
    }

    return res;
}