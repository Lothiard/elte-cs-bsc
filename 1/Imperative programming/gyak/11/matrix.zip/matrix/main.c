#include "matrix.h"
#include <stdio.h>
#include <stdlib.h>

int main() {
    Matrix *m1 = matrix_init(2, 2);
    Matrix *m2 = matrix_init(2, 2);

    /*
     * 1 2
     * 3 4
     */
    *matrix_at(m1, 0, 0) = 1;
    *matrix_at(m1, 0, 1) = 2;
    *matrix_at(m1, 1, 0) = 3;
    *matrix_at(m1, 1, 1) = 4;

    /* identity matrix */
    *matrix_at(m2, 0, 0) = 1;
    *matrix_at(m2, 1, 1) = 1;

    Matrix *prod = matrix_mul(m1, m2);

    printf("%d %d\n", *matrix_at(prod, 0, 0), *matrix_at(prod, 0, 1));
    printf("%d %d\n", *matrix_at(prod, 1, 0), *matrix_at(prod, 1, 1));

    free(m1);
    free(m2);
    free(prod);

    return 0;
}