-- 1.
module Hazi1 where
    -- 1.
    intExpr1 :: Int
    intExpr1 = undefined
    intExpr2 :: Int
    intExpr2 = undefined
    intExpr3 :: Int
    intExpr3 = undefined

    charExpr1 :: Char
    charExpr1 = undefined
    charExpr2 :: Char
    charExpr2 = undefined
    charExpr3 :: Char
    charExpr3 = undefined

    boolExpr1 :: Bool
    boolExpr1 = undefined
    boolExpr2 :: Bool
    boolExpr2 = undefined
    boolExpr3 :: Bool
    boolExpr3 = undefined

    -- 2.
    inc :: Integer -> Integer
    inc x = x + 1

    triple :: Integer -> Integer
    triple x = x * 3

    -- 3.
    thirteen1 :: Integer
    thirteen1 = inc (inc (inc (inc (triple (triple (inc 0))))))

    thirteen2 :: Integer
    thirteen2 = inc (inc (inc (inc (inc (inc (inc (triple (inc (inc 0)))))))))

    thirteen3 :: Integer
    thirteen3 = inc (inc (inc (inc (triple (inc (inc (inc 0)))))))

    -- 4.
    cmpRem5Rem7 :: Int -> Bool
    cmpRem5Rem7 x = mod x 5 > mod x 7

    -- 5.
    foo :: Int -> Bool -> Bool
    foo x y = y

    bar :: Bool -> Int -> Bool
    bar x y = foo y x
