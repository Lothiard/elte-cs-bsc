(window["canvasWebpackJsonp"]=window["canvasWebpackJsonp"]||[]).push([[498,580],{"/wcz":function(e,t,n){"use strict"
n.r(t)
var r=n("An8g")
function i(e,t,n){if(!e)return e
const r=(t||"").toString()
const i=(n||"").toString().replace(/\s/g,"+")
const o=new RegExp("(%7B|{){2}[\\s|%20|+]*".concat(r,"[\\s|%20|+]*(%7D|}){2}"),"g")
return e.replace(o,i)}function o(e,t,n){if("object"===typeof t){Object.keys(t).forEach(n=>{e=i(e,n,t[n])})
return e}return i(e,t,n)}var a=n("q1tI")
var s=n.n(a)
n("17x9")
var c=n("98st")
var l=n("gSD+")
var d=n("Mmr1")
var h=n("nhsw")
function u(e){const t=e.open,n=e.label,i=e.onOpen,o=e.onClose,a=e.onCloseButton,s=e.closeLabel,u=e.name,p=e.children
return Object(r["a"])(c["a"],{open:t,label:n,onOpen:i,onClose:o},void 0,Object(r["a"])(c["a"].Header,{},void 0,Object(r["a"])(d["a"],{placement:"end",offset:"medium",variant:"icon",onClick:a},void 0,s),Object(r["a"])(l["a"],{},void 0,u)),Object(r["a"])(c["a"].Body,{padding:"0"},void 0,Object(r["a"])(h["a"],{direction:"column"},void 0,p)))}var p=n("7Hz5")
var m=n("Xx/m")
var v=n("3Sge")
var g=n("WfMV")
function f(e){const t=e.open,n=e.label,i=e.onOpen,o=e.onClose,a=e.onCloseButton,s=e.closeLabel,c=e.name,d=e.children
return Object(r["a"])(p["a"],{open:t,label:n,onOpen:i,onClose:o,placement:"end",size:"regular"},void 0,Object(r["a"])(h["a"],{direction:"column",height:"100vh"},void 0,Object(r["a"])(h["a"].Item,{padding:"small medium"},void 0,Object(r["a"])(h["a"],{},void 0,Object(r["a"])(h["a"].Item,{grow:true,shrink:true},void 0,Object(r["a"])(l["a"],{ellipsis:true,level:"h3",as:"h2"},void 0,c)),Object(r["a"])(h["a"].Item,{},void 0,Object(r["a"])(m["a"],{variant:"icon",icon:v["a"],onClick:a,size:"small"},void 0,Object(r["a"])(g["a"],{},void 0,s))))),d))}var b=n("L+/K")
var y=n("pQTu")
var O=n("m0r6")
Object(O["a"])(JSON.parse('{"de":{"ExternalToolDialog":{"embed_from_external_tool":"Content aus externem Tool einbetten"},"are_you_sure_you_want_to_cancel_changes_you_made_m_c5210496":"Möchten Sie wirklich abbrechen? Vorgenommene Änderungen werden nicht gespeichert.","changes_you_made_may_not_be_saved_4e8db973":"Vorgenommene Änderungen werden nicht gespeichert.","close_d634289d":"Schließen","the_following_content_is_partner_provided_ed1da756":"Der folgende Content stammt von einem Partner.","the_preceding_content_is_partner_provided_d753928c":"Der vorhergehende Content stammt von einem Partner."},"hu":{"are_you_sure_you_want_to_cancel_changes_you_made_m_c5210496":"Biztos benne, hogy mégsem? A változtatásai talán nincsenek elmentve.","close_d634289d":"Bezárás"}}'))
n("jQeR")
n("0sPK")
var _=y["default"].scoped("ExternalToolDialog")
var j=n("xe+K")
var k=n("ouhR")
var w=n.n(k)
const x=["application/vnd.ims.lti.v1.ltilink","application/vnd.ims.lti.v1.launch+json"]
function I(e,t){t=t||Object.keys
function n(t){return{configurable:true,get:()=>e[t]}}let r,i=t(e),o=i.length
while(o--){r=i[o]
Object.defineProperty(this,r,n(r))}}function L(e){I.call(this,e)}function T(e){const t=window.tinyMCE&&window.tinyMCE.activeEditor.selection
const n=t&&t.getContent()
return n||e.text&&e.text.trim()||e.title&&e.title.trim()}L.fromJSON=function(e){return new L(e)}
const C={iframe:e=>w()("<div/>").append(w()("<iframe/>",{src:e.url,title:e.title,allowfullscreen:"true",webkitallowfullscreen:"true",mozallowfullscreen:"true",allow:"autoplay *"}).css({width:e.placementAdvice.displayWidth,height:e.placementAdvice.displayHeight}).attr({width:e.placementAdvice.displayWidth,height:e.placementAdvice.displayHeight})).html(),embed:e=>w()("<div/>").append(w()("<img/>",{src:e.url,alt:e.text}).css({width:e.placementAdvice.displayWidth,height:e.placementAdvice.displayHeight})).html(),text:e=>e.text,link(e){const t=w()("<div/>"),n=w()("<a/>",{href:e.url,title:e.title,target:e.linkTarget})
e.linkClassName&&n.addClass(e.linkClassName)
t.append(n)
e.thumbnail?n.append(w()("<img />",{src:e.thumbnail["@id"],height:e.thumbnail.height||48,width:e.thumbnail.width||48,alt:e.text})):window.tinyMCE.activeEditor.selection.getContent()?n[0].innerHTML=T(e):n.text(T(e))
return t.html()}}
function S(e){this.contentItem=e
const t=(e,t)=>{Object.defineProperty(this,e,{get:t.bind(this)})}
I.call(this,e,Object.getOwnPropertyNames)
t("isLTI",(function(){return!!~x.indexOf(this.mediaType)}))
t("isOverriddenForThumbnail",(function(){return this.isLTI&&this.thumbnail&&"iframe"===this.placementAdvice.presentationDocumentTarget}))
t("isImage",(function(){return this.mediaType&&0==this.mediaType.indexOf("image")}))
t("linkClassName",(function(){return this.isOverriddenForThumbnail?"lti-thumbnail-launch":""}))
t("url",(function(){return(this.isLTI?this.canvasURL:this.contentItem.url).replace(/^(data:text\/html|javascript:)/,"#$1")}))
t("linkTarget",(function(){if(this.isOverriddenForThumbnail)return JSON.stringify(this.placementAdvice)
return"window"==this.placementAdvice.presentationDocumentTarget.toLowerCase()?"_blank":null}))
t("docTarget",(function(){if("embed"==this.placementAdvice.presentationDocumentTarget&&!this.isImage)return"text"
if(this.isOverriddenForThumbnail)return"link"
return this.placementAdvice.presentationDocumentTarget.toLowerCase()}))
t("codePayload",(function(){switch(this.docTarget){case"iframe":return C.iframe(this)
case"embed":return C.embed(this)
case"text":return C.text(this)
default:return C.link(this)}}))}S.ContentItem=L
S.fromJSON=function(e){const t=L.fromJSON(e)
return new S(t)}
var B=S
var G=n("vknZ")
var A=n("6g+e")
function R(e,t,n){const r=G["a"].fromEvent(e,E)
if(!r)return
r.process(t).finally(()=>{n.close()}).catch(e=>{console.error(e)
w.a.flashError(A["a"].t("Error retrieving content"))})}async function E(e){this.contentItems.forEach(t=>{if(Object.keys(this.typeMap).includes(t.type)){const n=e.selection&&e.selection.getContent()
const r=new this.typeMap[t.type](t,this.ltiEndpoint,n)
Object(j["d"])(w()("#".concat(e.id)),"insert_code",r.toHtmlString())}})}n.d(t,"default",(function(){return F}))
const J={height:300,width:400,name:" "}
const z={url:"",selection:"",contents:""}
var M=Object(r["a"])("input",{type:"hidden",name:"editor",value:"1"})
class F extends s.a.Component{constructor(){super(...arguments)
this.state={open:false,button:J,infoAlert:null,form:z}
this.handleBeforeUnload=e=>e.returnValue=_.t("Changes you made may not be saved.")
this.handleExternalContentReady=(e,t)=>{const n=this.props,r=n.editor,i=n.win
const o=t.contentItems
if(1===o.length&&"lti_replace"===o[0]["@type"]){const e=o[0].text
Object(j["d"])(i.$("#".concat(r.id)),"set_code",e)}else for(let e=0,t=o.length;e<t;++e){const t=B.fromJSON(o[e]).codePayload
Object(j["d"])(i.$("#".concat(r.id)),"insert_code",t)}this.close()}
this.handleDeepLinking=e=>{const t=this.props,n=t.editor,r=t.deepLinkingOrigin
e.origin===r&&e.data&&"LtiDeepLinkingResponse"===e.data.messageType&&R(e,n,this)}
this.handleClose=()=>{const e=this.props.win
const t=_.t("Are you sure you want to cancel? Changes you made may not be saved.")
e.confirm(t)&&this.close()}
this.handleOpen=()=>this.formRef.submit()
this.handleRemove=()=>{this.setState({button:J})
this.props.editor.focus()}
this.handleInfoAlertFocus=e=>this.setState({infoAlert:e.target})
this.handleInfoAlertBlur=()=>this.setState({infoAlert:null})}open(e){const t=this.props,n=t.win,r=t.editor,i=t.contextAssetString,a=t.resourceSelectionUrl
let s=o(a,"id",e.id)
const c=r.selection.getContent()||""
const l=r.getContent()||""
if(null==s){const t=i.split("_")
s="/".concat(t[0],"s/").concat(t[1],"/external_tools/").concat(e.id,"/resource_selection")}this.setState({open:true,button:e,form:{url:s,selection:c,contents:l}})
n.addEventListener("beforeunload",this.handleBeforeUnload)
n.addEventListener("message",this.handleDeepLinking)
n.$(n).bind("externalContentReady",this.handleExternalContentReady)}close(){const e=this.props.win
e.removeEventListener("beforeunload",this.handleBeforeUnload)
e.removeEventListener("message",this.handleDeepLinking)
e.$(e).unbind("externalContentReady")
this.setState({open:false,form:z})}render(){const e=this.state,t=e.open,n=e.button,i=e.form,o=e.infoAlert
const a=this.props,c=a.iframeAllowances,l=a.win
const d=_.t("embed_from_external_tool","Embed content from External Tool")
const p=Math.max(Math.min(l.height-100,550),100)
const m=n.use_tray?f:u
return s.a.createElement(s.a.Fragment,null,s.a.createElement("form",{ref:e=>this.formRef=e,method:"POST",action:i.url,target:"external_tool_launch",style:{margin:0}},M,Object(r["a"])("input",{type:"hidden",name:"selection",value:i.selection}),Object(r["a"])("input",{type:"hidden",name:"editor_contents",value:i.contents})),Object(r["a"])(m,{open:t,label:d,onOpen:this.handleOpen,onClose:this.handleRemove,onCloseButton:this.handleClose,closeLabel:_.t("Close"),name:n.name},void 0,Object(r["a"])(h["a"].Item,{},void 0,s.a.createElement("div",{ref:e=>this.beforeInfoAlertRef=e,tabIndex:"0",onFocus:this.handleInfoAlertFocus,onBlur:this.handleInfoAlertBlur,className:o&&o===this.beforeInfoAlertRef?"":"screenreader-only"},Object(r["a"])(b["a"],{margin:"small"},void 0,_.t("The following content is partner provided")))),s.a.createElement("iframe",{title:d,ref:e=>this.iframeRef=e,name:"external_tool_launch",src:"/images/ajax-loader-medium-444.gif",id:"external_tool_button_frame",style:{flexGrow:"1",flexShrink:"1",width:n.use_tray?void 0:n.width||800,height:n.use_tray?void 0:n.height||p,border:"0"},allow:c,borderstyle:"0","data-lti-launch":"true"}),Object(r["a"])(h["a"].Item,{},void 0,s.a.createElement("div",{ref:e=>this.afterInfoAlertRef=e,tabIndex:"0",onFocus:this.handleInfoAlertFocus,onBlur:this.handleInfoAlertBlur,className:o&&o===this.afterInfoAlertRef?"":"screenreader-only"},Object(r["a"])(b["a"],{margin:"small"},void 0,_.t("The preceding content is partner provided"))))))}}F.defaultProps={resourceSelectionUrl:null,deepLinkingOrigin:""}},"3Sge":function(e,t,n){"use strict"
n.d(t,"a",(function(){return p}))
var r=n("VTBJ")
var i=n("1OyB")
var o=n("vuIU")
var a=n("md7G")
var s=n("foSv")
var c=n("Ji7U")
var l=n("q1tI")
var d=n.n(l)
var h=n("hPGw")
var u=d.a.createElement("path",{d:"M960.195 831.973L432.222 304 304 432.222l527.973 527.973L304 1488.168l128.222 128.222 527.973-527.973 527.973 527.973 128.222-128.222-527.973-527.973 527.973-527.973L1488.168 304z",fillRule:"nonzero",stroke:"none",strokeWidth:"1"})
var p=function(e){Object(c["a"])(t,e)
function t(){Object(i["a"])(this,t)
return Object(a["a"])(this,Object(s["a"])(t).apply(this,arguments))}Object(o["a"])(t,[{key:"render",value:function(){return d.a.createElement(h["a"],Object.assign({},this.props,{name:"IconX",viewBox:"0 0 1920 1920"}),u)}}])
t.displayName="IconXLine"
return t}(l["Component"])
p.glyphName="x"
p.variant="Line"
p.propTypes=Object(r["a"])({},h["a"].propTypes)},"6g+e":function(e,t,n){"use strict"
var r=n("pQTu")
var i=n("m0r6")
Object(i["a"])(JSON.parse('{"de":{"error_retrieving_content_c07ee76b":"Fehler beim Abrufen des Contents","external_content":{"success":{"content_failure":"Abruf der Inhalte fehlgeschlagen. Bitte versuchen Sie es erneut, oder melden Sie Ihrem Systemadministrator den Fehler.","oembed_failure":"Abruf der Inhalte fehlgeschlagen. Bitte versuchen Sie es erneut, oder melden Sie Ihrem Systemadministrator den Fehler.","popup_success":"Erfolgreich. Dieses Popup-Fenster sollte sich automatisch schließen ..."}},"retrieving_content_ed0b9b33":"Content wird abgerufen"},"hu":{"external_content":{"success":{"content_failure":"A tartalomlekérés sikertelen, kérjük, próbálja újra vagy értesítse a rendszeradminisztrátorát a hibáról.","oembed_failure":"A tartalomlekérés sikertelen, kérjük, próbálja újra vagy értesítse a rendszeradminisztrátorát a hibáról.","popup_success":"Sikerült! Ennek a felugró ablaknak el kellene tűnnie magától..."}}}}'))
n("jQeR")
n("0sPK")
t["a"]=r["default"].scoped("external_content.success")},"97gy":function(e,t,n){"use strict"
n.d(t,"a",(function(){return p}))
var r=n("VTBJ")
var i=n("1OyB")
var o=n("vuIU")
var a=n("md7G")
var s=n("foSv")
var c=n("Ji7U")
var l=n("q1tI")
var d=n.n(l)
var h=n("hPGw")
var u=d.a.createElement("path",{d:"M1743.858 267.012L710.747 1300.124 176.005 765.382 0 941.387l710.747 710.871 1209.24-1209.116z",fillRule:"evenodd",stroke:"none",strokeWidth:"1"})
var p=function(e){Object(c["a"])(t,e)
function t(){Object(i["a"])(this,t)
return Object(a["a"])(this,Object(s["a"])(t).apply(this,arguments))}Object(o["a"])(t,[{key:"render",value:function(){return d.a.createElement(h["a"],Object.assign({},this.props,{name:"IconCheckMark",viewBox:"0 0 1920 1920"}),u)}}])
t.displayName="IconCheckMarkSolid"
return t}(l["Component"])
p.glyphName="check-mark"
p.variant="Solid"
p.propTypes=Object(r["a"])({},h["a"].propTypes)},HVsT:function(e,t,n){"use strict"
n.d(t,"a",(function(){return p}))
var r=n("VTBJ")
var i=n("1OyB")
var o=n("vuIU")
var a=n("md7G")
var s=n("foSv")
var c=n("Ji7U")
var l=n("q1tI")
var d=n.n(l)
var h=n("hPGw")
var u=d.a.createElement("path",{d:"M213.333 960c0-167.36 56-321.707 149.44-446.4L1406.4 1557.227c-124.693 93.44-279.04 149.44-446.4 149.44-411.627 0-746.667-335.04-746.667-746.667m1493.334 0c0 167.36-56 321.707-149.44 446.4L513.6 362.773c124.693-93.44 279.04-149.44 446.4-149.44 411.627 0 746.667 335.04 746.667 746.667M960 0C429.76 0 0 429.76 0 960s429.76 960 960 960 960-429.76 960-960S1490.24 0 960 0",fillRule:"evenodd",stroke:"none",strokeWidth:"1"})
var p=function(e){Object(c["a"])(t,e)
function t(){Object(i["a"])(this,t)
return Object(a["a"])(this,Object(s["a"])(t).apply(this,arguments))}Object(o["a"])(t,[{key:"render",value:function(){return d.a.createElement(h["a"],Object.assign({},this.props,{name:"IconNo",viewBox:"0 0 1920 1920"}),u)}}])
t.displayName="IconNoSolid"
return t}(l["Component"])
p.glyphName="no"
p.variant="Solid"
p.propTypes=Object(r["a"])({},h["a"].propTypes)},J3yE:function(e,t,n){"use strict"
n.d(t,"a",(function(){return p}))
var r=n("VTBJ")
var i=n("1OyB")
var o=n("vuIU")
var a=n("md7G")
var s=n("foSv")
var c=n("Ji7U")
var l=n("q1tI")
var d=n.n(l)
var h=n("hPGw")
var u=d.a.createElement("path",{d:"M1072.156 537.778c59.802-.707 116.561 14.29 157.774 56.99 36.644 37.974 50.015 91.327 43.72 142.908-9.128 74.877-30.737 144.983-56.093 215.657-27.129 75.623-54.66 151.09-82.332 226.512-44.263 120.685-88.874 241.237-132.65 362.1-10.877 30.018-18.635 62.072-21.732 93.784-3.376 34.532 21.462 51.526 52.648 36.203 24.977-12.278 49.288-28.992 68.845-48.768 31.952-32.31 63.766-64.776 94.805-97.98 15.515-16.605 30.86-33.397 45.912-50.438 11.993-13.583 24.318-34.02 40.779-42.28 31.17-15.642 55.226 22.846 49.582 49.794-6.008 28.736-27.377 53.54-45.014 75.973-54.87 69.795-115.044 137.088-183.308 193.977-67.103 55.77-141.607 103.216-223.428 133.98-26.65 10.016-53.957 18.253-81.713 24.563-53.585 12.192-112.798 11.283-167.56 3.333-40.151-5.828-76.246-31.44-93.264-68.707-29.544-64.698-8.98-144.595 6.295-210.45 20.37-87.77 51.85-170.961 83.13-255.163 33.253-89.517 67.435-178.676 101.726-267.797 31.294-81.296 62.72-162.537 93.69-243.95 8.718-22.923 21.183-45.255 24.845-68.963 6.109-39.537-22.406-74.738-61.985-51.947-92.46 53.244-153.538 141.534-224.52 218.4-16.089 17.43-35.243 39.04-62.907 19.07-29.521-21.308-20.765-48.637-3.987-71.785 93.18-128.58 205.056-248.86 350.86-316.783 60.932-28.386 146.113-57.285 225.882-58.233zM1440 205.244c-.008 169.189-182.758 284.908-335.53 212.455-78.956-37.446-117.358-126.202-98.219-227.002 26.494-139.598 183.78-227.203 315.717-175.87 76.703 29.846 118.04 96.533 118.032 190.417z",fillRule:"evenodd",stroke:"none",strokeWidth:"1"})
var p=function(e){Object(c["a"])(t,e)
function t(){Object(i["a"])(this,t)
return Object(a["a"])(this,Object(s["a"])(t).apply(this,arguments))}Object(o["a"])(t,[{key:"render",value:function(){return d.a.createElement(h["a"],Object.assign({},this.props,{name:"IconInfoBorderless",viewBox:"0 0 1920 1920"}),u)}}])
t.displayName="IconInfoBorderlessSolid"
return t}(l["Component"])
p.glyphName="info-borderless"
p.variant="Solid"
p.propTypes=Object(r["a"])({},h["a"].propTypes)},"L+/K":function(e,t,n){"use strict"
var r=n("1OyB")
var i=n("vuIU")
var o=n("md7G")
var a=n("foSv")
var s=n("Ji7U")
n("DEX3")
var c=n("q1tI")
var l=n.n(c)
var d=n("i8i4")
var h=n.n(d)
var u=n("17x9")
var p=n.n(u)
var m=n("TSYQ")
var v=n.n(m)
var g=n("3zPy")
var f=n.n(g)
var b=n("nAyT")
var y=n("E+IV")
var O=n("Mmr1")
var _=n("n12J")
var j=n("6SzX")
var k=n("HVsT")
var w=n("J3yE")
var x=n("97gy")
var I=n("znKQ")
var L=n("XQb/")
var T=n("J2CL")
var C=n("BTe1")
function S(e){var t=e.colors,n=e.borders,r=e.spacing,i=e.typography,o=e.shadows
return{background:t.backgroundLightest,color:t.textDarkest,marginTop:r.small,borderRadius:n.radiusMedium,borderWidth:n.widthMedium,borderStyle:n.style,contentPadding:"".concat(r.small," ").concat(r.medium),contentFontSize:i.fontSizeMedium,contentFontFamily:i.fontFamily,contentFontWeight:i.fontWeightNormal,contentLineHeight:i.lineHeightCondensed,closeButtonMarginTop:r.xSmall,closeButtonMarginRight:r.xxSmall,iconColor:t.textLightest,iconBackground:t.backgroundLightest,successBorderColor:t.borderSuccess,successIconBackground:t.backgroundSuccess,infoBorderColor:t.borderInfo,infoIconBackground:t.backgroundInfo,warningBorderColor:t.borderWarning,warningIconBackground:t.backgroundWarning,dangerBorderColor:t.borderDanger,dangerIconBackground:t.backgroundDanger,boxShadow:o.depth2}}S.canvas=function(e){return{color:e["ic-brand-font-color-dark"]}}
n.d(t,"a",(function(){return z}))
var B,G,A,R,E
var J={componentId:"cvphu",template:function(e){return"\n\n.cvphu_bgqc{background:".concat(e.background||"inherit",";border-radius:").concat(e.borderRadius||"inherit",";border-style:").concat(e.borderStyle||"inherit",";border-width:").concat(e.borderWidth||"inherit",";box-shadow:").concat(e.boxShadow||"inherit",";color:").concat(e.color||"inherit",";display:flex;min-width:12rem}\n\n.cvphu_bgqc,.cvphu_caGd{box-sizing:border-box}\n\n.cvphu_caGd{flex:1;font-family:").concat(e.contentFontFamily||"inherit",";font-size:").concat(e.contentFontSize||"inherit",";font-weight:").concat(e.contentFontWeight||"inherit",";line-height:").concat(e.contentLineHeight||"inherit",";min-width:0.0625rem;padding:").concat(e.contentPadding||"inherit","}\n\n.cvphu_dnnz{align-items:center;border-right:").concat(e.borderWidth||"inherit"," ").concat(e.borderStyle||"inherit",";color:").concat(e.iconColor||"inherit",";flex:0 0 2.5rem;font-size:1.125rem;justify-content:center}\n\n.cvphu_fsGh,.cvphu_dnnz{box-sizing:border-box;display:flex}\n\n.cvphu_fsGh{align-items:flex-start;margin-right:").concat(e.closeButtonMarginRight||"inherit",";margin-top:").concat(e.closeButtonMarginTop||"inherit",";order:1}\n\n.cvphu_cOXX{border-color:").concat(e.successBorderColor||"inherit","}\n\n.cvphu_cOXX .cvphu_dnnz{background-color:").concat(e.successIconBackground||"inherit",";border-right-color:").concat(e.successIconBackground||"inherit","}\n\n.cvphu_pypk{border-color:").concat(e.infoBorderColor||"inherit","}\n\n.cvphu_pypk .cvphu_dnnz{background:").concat(e.infoIconBackground||"inherit",";border-right-color:").concat(e.infoIconBackground||"inherit","}\n\n.cvphu_ddvR{border-color:").concat(e.dangerBorderColor||"inherit","}\n\n.cvphu_ddvR .cvphu_dnnz{background:").concat(e.dangerIconBackground||"inherit",";border-right-color:").concat(e.dangerIconBackground||"inherit","}\n\n.cvphu_eRqw{border-color:").concat(e.warningBorderColor||"inherit","}\n\n.cvphu_eRqw .cvphu_dnnz{background:").concat(e.warningIconBackground||"inherit",";border-right-color:").concat(e.warningIconBackground||"inherit","}")},alert:"cvphu_bgqc",content:"cvphu_caGd",icon:"cvphu_dnnz",closeButton:"cvphu_fsGh",success:"cvphu_cOXX",info:"cvphu_pypk",error:"cvphu_ddvR",warning:"cvphu_eRqw"}
var z=(B=Object(b["a"])("7.0.0",{closeButtonLabel:"renderCloseButtonLabel"}),G=Object(T["themeable"])(S,J),B(A=G(A=(E=R=function(e){Object(s["a"])(t,e)
function t(e){var n
Object(r["a"])(this,t)
n=Object(o["a"])(this,Object(a["a"])(t).call(this,e))
n._timeouts=[]
n.handleTimeout=function(){n.props.timeout>0&&n._timeouts.push(setTimeout((function(){n.close()}),n.props.timeout))}
n.onExitTransition=function(){n.props.onDismiss&&n.props.onDismiss()}
n.close=function(){n.clearTimeouts()
n.removeScreenreaderAlert()
n.setState({open:false},(function(){n.props.onDismiss&&"none"===n.props.transition&&n.props.onDismiss()}))}
n.handleKeyUp=function(e){(n.props.renderCloseButtonLabel||n.props.closeButtonLabel)&&e.keyCode===f.a.codes.esc&&n.close()}
n.state={open:true}
return n}Object(i["a"])(t,[{key:"variantUI",value:function(){return{error:{Icon:k["a"],classNames:v()(J.alert,J.error)},info:{Icon:w["a"],classNames:v()(J.alert,J.info)},success:{Icon:x["a"],classNames:v()(J.alert,J.success)},warning:{Icon:I["a"],classNames:v()(J.alert,J.warning)}}[this.props.variant]}},{key:"clearTimeouts",value:function(){this._timeouts.forEach((function(e){return clearTimeout(e)}))
this._timeouts=[]}},{key:"isDOMNode",value:function(e){return e&&"object"===typeof e&&1===e.nodeType}},{key:"getLiveRegion",value:function(){var e=null
"function"===typeof this.props.liveRegion&&(e=this.props.liveRegion())
return this.isDOMNode(e)?e:null}},{key:"initLiveRegion",value:function(e){e.getAttribute("role")
if(e){e.setAttribute("aria-live",this.props.liveRegionPoliteness)
e.setAttribute("aria-relevant","additions text")
e.setAttribute("aria-atomic",this.props.isLiveRegionAtomic)}}},{key:"createScreenreaderContentNode",value:function(){return l.a.createElement(j["a"],null,this.props.children)}},{key:"createScreenreaderAlert",value:function(){var e=this.getLiveRegion()
if(e){this.srid=Object(C["a"])("Alert")
var t=document.createElement("div")
t.setAttribute("id",this.srid)
var n=this.createScreenreaderContentNode()
h.a.render(n,t)
e.appendChild(t)}}},{key:"updateScreenreaderAlert",value:function(){var e=this
if(this.getLiveRegion()){var t=document.getElementById(this.srid)
t&&h.a.render(null,t,(function(){var n=e.createScreenreaderContentNode()
h.a.render(n,t)}))}}},{key:"removeScreenreaderAlert",value:function(){var e=this.getLiveRegion()
if(e){var t=document.getElementById(this.srid)
if(t){e.removeAttribute("aria-live")
e.removeAttribute("aria-relevant")
e.removeAttribute("aria-atomic")
h.a.unmountComponentAtNode(t)
t.parentNode.removeChild(t)
this.initLiveRegion(e)}}}},{key:"componentDidMount",value:function(){var e=this.getLiveRegion()
e&&this.initLiveRegion(e)
this.handleTimeout()
this.createScreenreaderAlert()}},{key:"componentDidUpdate",value:function(e){false===!!this.props.open&&!!this.props.open!==!!e.open?this.close():this.props.children!==e.children&&this.updateScreenreaderAlert()}},{key:"componentWillUnmount",value:function(){this.removeScreenreaderAlert()
this.clearTimeouts()}},{key:"renderIcon",value:function(){var e=this.variantUI(),t=e.Icon
return l.a.createElement("div",{className:J.icon},l.a.createElement(t,{className:J.alertIcon}))}},{key:"renderCloseButton",value:function(){var e=this.props.renderCloseButtonLabel&&Object(y["a"])(this.props.renderCloseButtonLabel)||this.props.closeButtonLabel
return e?l.a.createElement("div",{className:J.closeButton,key:"closeButton"},l.a.createElement(O["a"],{onClick:this.close,size:"small",variant:"icon"},e)):null}},{key:"renderAlert",value:function(){var e=this.variantUI(),t=e.classNames
return l.a.createElement(_["a"],{as:"div",margin:this.props.margin,className:t,onKeyUp:this.handleKeyUp},this.renderIcon(),l.a.createElement("div",{className:J.content},this.props.children),this.renderCloseButton())}},{key:"render",value:function(){if(this.props.screenReaderOnly){this.getLiveRegion()
return null}if("none"===this.props.transition)return this.state.open?this.renderAlert():null
return l.a.createElement(L["a"],{type:this.props.transition,transitionOnMount:true,in:this.state.open,unmountOnExit:true,onExited:this.onExitTransition},this.renderAlert())}}])
t.displayName="Alert"
return t}(c["Component"]),R.propTypes={children:p.a.node,variant:p.a.oneOf(["info","success","warning","error"]),margin:T["ThemeablePropTypes"].spacing,liveRegion:p.a.func,liveRegionPoliteness:p.a.oneOf(["polite","assertive"]),isLiveRegionAtomic:p.a.bool,screenReaderOnly:p.a.bool,timeout:p.a.number,renderCloseButtonLabel:p.a.oneOfType([p.a.func,p.a.node]),closeButtonLabel:p.a.string,onDismiss:p.a.func,transition:p.a.oneOf(["none","fade"]),open:p.a.bool},R.defaultProps={variant:"info",margin:"x-small 0",timeout:0,transition:"fade",open:true,screenReaderOnly:false,liveRegionPoliteness:"assertive",isLiveRegionAtomic:false,onDismiss:void 0,liveRegion:void 0,renderCloseButtonLabel:void 0,closeButtonLabel:void 0,children:null},E))||A)||A)},O7M4:function(e,t,n){"use strict"
var r=n("rePB")
var i=n("1OyB")
var o=n("vuIU")
var a=n("md7G")
var s=n("foSv")
var c=n("Ji7U")
var l=n("q1tI")
var d=n.n(l)
var h=n("17x9")
var u=n.n(h)
var p=n("TSYQ")
var m=n.n(p)
var v=n("J2CL")
var g=n("jtGx")
var f=n("n12J")
function b(e){var t=e.colors
return{debugOutlineColor:t.borderSuccess}}n.d(t,"a",(function(){return w}))
var y,O,_,j
var k={componentId:"dHGMZ",template:function(e){return"\n\n.dHGMZ_bGBk{box-sizing:border-box;flex-shrink:0;min-width:0.0625rem}\n\n.dHGMZ_ffgL{align-self:flex-start}\n\n.dHGMZ_fjOx{align-self:flex-end}\n\n.dHGMZ_bJAR{align-self:center}\n\n.dHGMZ_eFer{align-self:stretch}\n\n.dHGMZ_SpYf{flex-grow:1}\n\n.dHGMZ_buwJ{flex-shrink:1}\n\n.dHGMZ_fFVr{outline:0.0625rem dashed ".concat(e.debugOutlineColor||"inherit","}")},root:"dHGMZ_bGBk","align--start":"dHGMZ_ffgL","align--end":"dHGMZ_fjOx","align--center":"dHGMZ_bJAR","align--stretch":"dHGMZ_eFer",grow:"dHGMZ_SpYf",shrink:"dHGMZ_buwJ",visualDebug:"dHGMZ_fFVr"}
var w=(y=Object(v["themeable"])(b,k),y(O=(j=_=function(e){Object(c["a"])(t,e)
function t(){Object(i["a"])(this,t)
return Object(a["a"])(this,Object(s["a"])(t).apply(this,arguments))}Object(o["a"])(t,[{key:"render",value:function(){var e
var n=Object(g["a"])(this.props,t.propTypes)
var i=this.props,o=i.align,a=i.as,s=i.elementRef,c=i.children,l=i.direction,h=i.grow,u=i.margin,p=i.overflowX,v=i.overflowY,b=i.padding,y=i.shrink,O=i.size,_=i.textAlign,j=i.visualDebug
var w="column"===l
var x={flexBasis:O}
var I=(e={},Object(r["a"])(e,k.root,true),Object(r["a"])(e,k.visualDebug,j),Object(r["a"])(e,k.grow,h),Object(r["a"])(e,k.shrink,y),Object(r["a"])(e,k["align--".concat(o)],o),e)
return d.a.createElement(f["a"],Object.assign({},n,{className:m()(I),style:x,elementRef:s,as:a,minHeight:w?O:void 0,minWidth:"row"===l?O:void 0,textAlign:_,margin:u,padding:b,overflowX:p,overflowY:v||(w?"auto":"visible")}),c)}}])
t.displayName="FlexItem"
return t}(l["Component"]),_.propTypes={align:u.a.oneOf(["center","start","end","stretch"]),as:u.a.elementType,elementRef:u.a.func,children:u.a.node,direction:u.a.oneOf(["row","column"]),grow:u.a.bool,shrink:u.a.bool,size:u.a.string,textAlign:u.a.oneOf(["start","center","end"]),margin:v["ThemeablePropTypes"].spacing,padding:v["ThemeablePropTypes"].spacing,visualDebug:u.a.bool,overflowX:u.a.oneOf(["auto","hidden","visible"]),overflowY:u.a.oneOf(["auto","hidden","visible"])},_.defaultProps={as:"span",elementRef:function(e){},grow:false,shrink:false},j))||O)},"gSD+":function(e,t,n){"use strict"
var r=n("rePB")
var i=n("1OyB")
var o=n("vuIU")
var a=n("md7G")
var s=n("foSv")
var c=n("Ji7U")
var l=n("q1tI")
var d=n.n(l)
var h=n("17x9")
var u=n.n(h)
var p=n("TSYQ")
var m=n.n(p)
var v=n("n12J")
var g=n("J2CL")
var f=n("RhCJ")
var b=n("nAyT")
var y=n("KgFQ")
var O=n("jtGx")
var _=n("oXx0")
function j(e){var t=e.borders,n=e.colors,r=e.spacing,i=e.typography
return{fontFamily:i.fontFamily,fontWeight:i.fontWeightNormal,lineHeight:i.lineHeightFit,h1FontSize:i.fontSizeXXLarge,h1FontWeight:i.fontWeightLight,h2FontSize:i.fontSizeXLarge,h2FontWeight:i.fontWeightNormal,h3FontSize:i.fontSizeLarge,h3FontWeight:i.fontWeightBold,h4FontSize:i.fontSizeMedium,h4FontWeight:i.fontWeightBold,h5FontSize:i.fontSizeSmall,h5FontWeight:i.fontWeightNormal,primaryInverseColor:n.textLightest,primaryColor:n.textDarkest,secondaryColor:n.textDark,secondaryInverseColor:n.textLight,brandColor:n.textBrand,warningColor:n.textWarning,errorColor:n.textDanger,successColor:n.textSuccess,borderPadding:r.xxxSmall,borderColor:n.borderMedium,borderWidth:t.widthSmall,borderStyle:t.style}}j.canvas=function(e){return{primaryColor:e["ic-brand-font-color-dark"],brandColor:e["ic-brand-primary"]}}
n.d(t,"a",(function(){return S}))
var k,w,x,I,L,T
var C={componentId:"emyav",template:function(e){return"\n\n.emyav_bGBk{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:".concat(e.fontFamily||"inherit",";line-height:").concat(e.lineHeight||"inherit",";margin:0;text-rendering:optimizeLegibility}\n\ninput.emyav_bGBk[type]{-moz-appearance:none;-webkit-appearance:none;appearance:none;background:none;border:none;border-radius:0;box-shadow:none;box-sizing:border-box;color:inherit;display:block;height:auto;line-height:inherit;margin:-6px 0 0 0;outline:0;padding:0;text-align:start;width:100%}\n\n[dir=ltr] input.emyav_bGBk[type]{text-align:left}\n\n[dir=rtl] input.emyav_bGBk[type]{text-align:right}\n\ninput.emyav_bGBk[type]:focus{outline:none}\n\n.emyav_fIqS{font-size:").concat(e.h1FontSize||"inherit",";font-weight:").concat(e.h1FontWeight||"inherit","}\n\n.emyav_eABG{font-size:").concat(e.h2FontSize||"inherit",";font-weight:").concat(e.h2FontWeight||"inherit","}\n\n.emyav_dlZd{font-size:").concat(e.h3FontSize||"inherit",";font-weight:").concat(e.h3FontWeight||"inherit","}\n\n.emyav_bAmB{font-size:").concat(e.h4FontSize||"inherit",";font-weight:").concat(e.h4FontWeight||"inherit","}\n\n.emyav_eRZv{font-size:").concat(e.h5FontSize||"inherit",";font-weight:").concat(e.h5FontWeight||"inherit","}\n\n.emyav_dTMd{border-top:").concat(e.borderWidth||"inherit"," ").concat(e.borderStyle||"inherit"," ").concat(e.borderColor||"inherit",";padding-top:").concat(e.borderPadding||"inherit","}\n\n.emyav_evMo{border-bottom:").concat(e.borderWidth||"inherit"," ").concat(e.borderStyle||"inherit"," ").concat(e.borderColor||"inherit",";padding-bottom:").concat(e.borderPadding||"inherit","}\n\n.emyav_fAVi{color:inherit}\n\n.emyav_qFsi{color:").concat(e.primaryColor||"inherit","}\n\n.emyav_bLsb{color:").concat(e.secondaryColor||"inherit","}\n\n.emyav_ezBQ{color:").concat(e.primaryInverseColor||"inherit","}\n\n.emyav_dlnd{color:").concat(e.secondaryInverseColor||"inherit","}\n\n.emyav_ZpoW{font-size:inherit;font-weight:inherit;line-height:inherit;margin:0}\n\n.emyav_bOQC{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}")},root:"emyav_bGBk",h1:"emyav_fIqS",h2:"emyav_eABG",h3:"emyav_dlZd",h4:"emyav_bAmB",h5:"emyav_eRZv","border-top":"emyav_dTMd","border-bottom":"emyav_evMo","color-inherit":"emyav_fAVi","color-primary":"emyav_qFsi","color-secondary":"emyav_bLsb","color-primary-inverse":"emyav_ezBQ","color-secondary-inverse":"emyav_dlnd",reset:"emyav_ZpoW",ellipsis:"emyav_bOQC"}
var S=(k=Object(b["a"])("7.0.0",null,"Use Heading from ui-heading instead."),w=Object(_["a"])(),x=Object(g["themeable"])(j,C),k(I=w(I=x(I=(T=L=function(e){Object(c["a"])(t,e)
function t(){Object(i["a"])(this,t)
return Object(a["a"])(this,Object(s["a"])(t).apply(this,arguments))}Object(o["a"])(t,[{key:"render",value:function(){var e
var n=this.props,i=n.border,o=n.children,a=n.color,s=n.level,c=n.ellipsis,l=n.margin,h=n.elementRef
var u=Object(y["a"])(t,this.props,(function(){return"reset"===s?"span":s}))
var p=v["a"].omitViewProps(Object(O["a"])(this.props,t.propTypes),t)
return d.a.createElement(v["a"],Object.assign({},p,{className:m()((e={},Object(r["a"])(e,C.root,true),Object(r["a"])(e,C[s],true),Object(r["a"])(e,C["color-".concat(a)],a),Object(r["a"])(e,C["border-".concat(i)],"none"!==i),Object(r["a"])(e,C.ellipsis,c),e)),as:u,margin:l,elementRef:h}),o)}}])
t.displayName="Heading"
return t}(l["Component"]),L.propTypes={border:u.a.oneOf(["none","top","bottom"]),children:f["a"],color:u.a.oneOf(["primary","secondary","primary-inverse","secondary-inverse","inherit"]),level:u.a.oneOf(["h1","h2","h3","h4","h5","reset"]),as:u.a.elementType,ellipsis:u.a.bool,margin:g["ThemeablePropTypes"].spacing,elementRef:u.a.func},L.defaultProps={children:null,margin:void 0,elementRef:void 0,border:"none",color:"inherit",level:"h2",ellipsis:false},T))||I)||I)||I)},nhsw:function(e,t,n){"use strict"
var r=n("rePB")
var i=n("VTBJ")
var o=n("1OyB")
var a=n("vuIU")
var s=n("md7G")
var c=n("foSv")
var l=n("Ji7U")
var d=n("q1tI")
var h=n.n(d)
var u=n("17x9")
var p=n.n(u)
var m=n("TSYQ")
var v=n.n(m)
var g=n("J2CL")
var f=n("dpqJ")
var b=n("nAyT")
var y=n("II2N")
var O=n("jtGx")
var _=n("n12J")
var j=n("O7M4")
function k(e){var t=e.colors,n=e.typography
return{fontFamily:n.fontFamily,debugOutlineColor:t.borderDebug}}n.d(t,"a",(function(){return S}))
var w,x,I,L,T
var C={componentId:"cGJLp",template:function(e){return"\n\n.cGJLp_bGBk{box-sizing:border-box;font-family:".concat(e.fontFamily||"inherit","}\n\n.cGJLp_bZNM{flex-direction:column}\n\n.cGJLp_eUXf{flex-direction:column-reverse}\n\n.cGJLp_qOas{flex-direction:row}\n\n.cGJLp_sGoV{flex-direction:row-reverse}\n\n.cGJLp_ePRQ{flex-wrap:wrap}\n\n.cGJLp_busO{justify-content:flex-start}\n\n.cGJLp_crdn{justify-content:flex-end}\n\n.cGJLp_eRIA{justify-content:center}\n\n.cGJLp_flTs{justify-content:space-around}\n\n.cGJLp_oDLF{justify-content:space-between}\n\n.cGJLp_fZWR{align-items:center}\n\n.cGJLp_cCxO{align-items:flex-start}\n\n.cGJLp_fncw{align-items:flex-end}\n\n.cGJLp_cQFX{align-items:stretch}\n\n.cGJLp_fFVr{outline:0.0625rem dashed ").concat(e.debugOutlineColor||"inherit","}")},root:"cGJLp_bGBk",column:"cGJLp_bZNM","column-reverse":"cGJLp_eUXf",row:"cGJLp_qOas","row-reverse":"cGJLp_sGoV",wrapItems:"cGJLp_ePRQ","justifyItems--start":"cGJLp_busO","justifyItems--end":"cGJLp_crdn","justifyItems--center":"cGJLp_eRIA","justifyItems--space-around":"cGJLp_flTs","justifyItems--space-between":"cGJLp_oDLF","alignItems--center":"cGJLp_fZWR","alignItems--start":"cGJLp_cCxO","alignItems--end":"cGJLp_fncw","alignItems--stretch":"cGJLp_cQFX",visualDebug:"cGJLp_fFVr"}
var S=(w=Object(b["a"])("7.0.0",null,"Use Flex from ui-flex instead."),x=Object(g["themeable"])(k,C),w(I=x(I=(T=L=function(e){Object(l["a"])(t,e)
function t(){Object(o["a"])(this,t)
return Object(s["a"])(this,Object(c["a"])(t).apply(this,arguments))}Object(a["a"])(t,[{key:"renderChildren",value:function(){var e=this
return d["Children"].map(this.props.children,(function(t){return t?Object(y["a"])(t,Object(i["a"])({visualDebug:e.props.visualDebug},t.props,{direction:e.props.direction.replace(/-reverse/,"")})):null}))}},{key:"render",value:function(){var e
var n=Object(O["a"])(this.props,t.propTypes)
var i=this.props,o=i.as,a=i.elementRef,s=i.children,c=i.direction,l=i.height,d=i.inline,u=i.margin,p=i.padding,m=i.justifyItems,g=i.textAlign,f=i.visualDebug,b=i.width,y=i.wrapItems
var j=this.props.alignItems||("column"===c||"column-reverse"===c?"stretch":"center")
var k=(e={},Object(r["a"])(e,C.root,true),Object(r["a"])(e,C.visualDebug,f),Object(r["a"])(e,C["justifyItems--".concat(m)],true),Object(r["a"])(e,C["alignItems--".concat(j)],true),Object(r["a"])(e,C.wrapItems,y),e)
return s&&h.a.Children.count(s)>0?h.a.createElement(_["a"],Object.assign({},n,{className:v()(k,C[c]),elementRef:a,as:o,display:d?"inline-flex":"flex",width:b,height:l,margin:u,padding:p,textAlign:g}),this.renderChildren()):null}}])
t.displayName="Flex"
return t}(d["Component"]),L.propTypes={children:f["a"].oneOf([j["a"]]),as:p.a.elementType,elementRef:p.a.func,direction:p.a.oneOf(["row","column","row-reverse","column-reverse"]),height:p.a.oneOfType([p.a.string,p.a.number]),width:p.a.oneOfType([p.a.string,p.a.number]),inline:p.a.bool,textAlign:p.a.oneOf(["start","center","end"]),margin:g["ThemeablePropTypes"].spacing,padding:g["ThemeablePropTypes"].spacing,alignItems:p.a.oneOf(["center","start","end","stretch"]),justifyItems:p.a.oneOf(["center","start","end","space-around","space-between"]),visualDebug:p.a.bool,wrapItems:p.a.bool},L.defaultProps={children:null,as:"span",elementRef:function(e){},direction:"row",justifyItems:"start",inline:false,visualDebug:false,wrapItems:false,width:void 0,height:void 0,padding:void 0,margin:void 0,alignItems:void 0,textAlign:void 0},L.Item=j["a"],T))||I)||I)},vknZ:function(e,t,n){"use strict"
var r=n("ouhR")
var i=n.n(r)
var o=n("mykf")
class a{constructor(e){this.assignProperties(e)}toHtmlString(){}assignProperties(e){this.properties.forEach(t=>{this[t]=e[t]})}linkThumbnail(){return this.imageTag(this.thumbnail)}iframeTag(){const e=this.iframe
if(e){const t=document.createElement("iframe")
t.setAttribute("src",e.src)
t.setAttribute("title",this.title||"")
t.setAttribute("allowfullscreen","true")
t.setAttribute("allow",Object(o["a"])())
e.width&&(t.style.width="".concat(e.width,"px"))
e.height&&(t.style.height="".concat(e.height,"px"))
return t.outerHTML}}imageTag(e,t,n){const r=document.createElement("img")
r.setAttribute("src",e)
this.text&&r.setAttribute("alt",this.text)
t&&r.setAttribute("width",t)
n&&r.setAttribute("height",n)
return r.outerHTML}anchorTag(e){const t=document.createElement("a")
t.setAttribute("href",this.safeUrl())
t.setAttribute("title",this.title)
t.setAttribute("target","_blank")
t.innerHTML=e
return t.outerHTML}safeUrl(){return this.url.replace(/^(data:text\/html|javascript:)/,"#$1")}}class s extends a{constructor(e,t,n){super(e)
this.type=s.type
n&&""!==n&&(this.text=n)}get properties(){return Object.freeze(["url","title","text","icon","thumbnail","iframe"])}toHtmlString(){if(this.iframe&&this.iframe.src)return this.iframeTag()
return this.anchorTag(this.linkBody())}linkText(){return this.text&&this.text.trim()||this.title&&this.title.trim()}linkBody(){if(this.thumbnail)return this.linkThumbnail()
return this.linkText()}}s.type="link"
class c extends s{constructor(e,t,n){super(e,t,n)
this.url="".concat(t,"?").concat(this.ltiEndpointParams(e.url))}ltiEndpointParams(e){return"display=borderless&url=".concat(encodeURIComponent(e))}toHtmlString(){if(this.iframe){this.iframe.src=this.safeUrl()
return this.iframeTag()}return this.anchorTag(this.linkBody())}}class l extends a{constructor(e){super(e)
this.type=l.type}get properties(){return Object.freeze(["url","title","thumbnail","text","width","height"])}toHtmlString(){if(this.thumbnail)return this.anchorTag(this.linkThumbnail())
return this.imageTag(this.safeUrl(),this.width,this.height)}}l.type="image"
class d extends a{constructor(e){super(e)
this.type=d.type}get properties(){return Object.freeze(["html","title","text"])}toHtmlString(){return this.html}}d.type="html"
n.d(t,"a",(function(){return h}))
class h{constructor(e,t,n,r,i){this.contentItems=e
this.messages=t
this.logs=n
this.ltiEndpoint=r
this.processHandler=i
this.showMessages()
this.showLogs()}get loggingEnabled(){return ENV&&ENV.DEEP_LINKING_LOGGING}get typeMap(){return{link:s,ltiResourceLink:c,image:l,html:d}}static fromEvent(e,t){const n=e.data,r=n.content_items,i=n.msg,o=n.log,a=n.errormsg,s=n.errorlog,c=n.ltiEndpoint,l=n.messageType
if("LtiDeepLinkingResponse"!==l)return
return new this(r,{msg:i,errormsg:a},{log:o,errorlog:s},c,t)}process(){return this.processHandler(...arguments)}showMessages(){this.messages.errormsg&&i.a.flashError(this.messages.errormsg)
this.messages.msg&&i.a.flashMessage(this.messages.msg)}showLogs(){if(this.loggingEnabled){this.logs.errorlog&&console.error(this.logs.errorlog)
this.logs.log&&console.log(this.logs.log)}}}},znKQ:function(e,t,n){"use strict"
n.d(t,"a",(function(){return p}))
var r=n("VTBJ")
var i=n("1OyB")
var o=n("vuIU")
var a=n("md7G")
var s=n("foSv")
var c=n("Ji7U")
var l=n("q1tI")
var d=n.n(l)
var h=n("hPGw")
var u=d.a.createElement("g",{fillRule:"evenodd",stroke:"none",strokeWidth:"1"},d.a.createElement("path",{d:"M994.578 1436.356c-133.365 0-241.822 108.457-241.822 241.822S861.213 1920 994.578 1920s241.822-108.457 241.822-241.822-108.457-241.822-241.822-241.822zM1165.063 1315.444L1310.156 0H679l145.093 1315.444z"}))
var p=function(e){Object(c["a"])(t,e)
function t(){Object(i["a"])(this,t)
return Object(a["a"])(this,Object(s["a"])(t).apply(this,arguments))}Object(o["a"])(t,[{key:"render",value:function(){return d.a.createElement(h["a"],Object.assign({},this.props,{name:"IconWarningBorderless",viewBox:"0 0 1920 1920"}),u)}}])
t.displayName="IconWarningBorderlessSolid"
return t}(l["Component"])
p.glyphName="warning-borderless"
p.variant="Solid"
p.propTypes=Object(r["a"])({},h["a"].propTypes)}}])

//# sourceMappingURL=498-c-2f31c934fa.js.map