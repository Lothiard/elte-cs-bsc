namespace HF8 {
    public class FileSystem : Folder { }
}