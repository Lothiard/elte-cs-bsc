namespace HF8 {
    public class Registration {
        // not implemented lol
        public virtual int GetSize() {
            return 0;
        }
    }
}