using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Bevetel {
    internal class Program {
        static void Main (string[] args) {
            if (args.Length == 0) {
                Console.WriteLine("K�rj�k, adja meg a bemeneti f�jl el�r�si �tvonal�t.");
                return;
            }

            string filePath = args[0];
            List<Szamla> szamlak = new List<Szamla>();

            try {
                using (StreamReader reader = new StreamReader(filePath)) {
                    string line;
                    while ((line = reader.ReadLine()) != null) {
                        string[] parts = line.Split(' ');
                        if (parts.Length < 2) continue;

                        string nev = parts[0];
                        Szamla szamla = new Szamla(nev);

                        for (int i = 1; i < parts.Length; i += 2) {
                            if (i + 1 >= parts.Length) break;

                            string cikkszam = parts[i];
                            if (!float.TryParse(parts[i + 1], out float ar)) continue;

                            Aru aru = new Aru(cikkszam, ar);
                            szamla.HozzaadAru(aru);
                        }

                        szamlak.Add(szamla);
                    }
                }

                float osszesOsszeg = szamlak.Sum(s => s.Osszeg);
                Console.WriteLine(osszesOsszeg);
            } catch (Exception ex) {
                Console.WriteLine($"Hiba t�rt�nt a f�jl feldolgoz�sa sor�n: {ex.Message}");
            }
        }
    }
}
