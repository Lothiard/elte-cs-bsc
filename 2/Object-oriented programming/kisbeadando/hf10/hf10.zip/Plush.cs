namespace HF10 {
    public class Plush : Gift {
        public Plush(Size size) : base(size) {}

        public override int Point() {
            return 3;
        }
    }
}
