namespace Nagybead {
    public interface IPalyaTipus {
        int PalyaAr();
    }
}
